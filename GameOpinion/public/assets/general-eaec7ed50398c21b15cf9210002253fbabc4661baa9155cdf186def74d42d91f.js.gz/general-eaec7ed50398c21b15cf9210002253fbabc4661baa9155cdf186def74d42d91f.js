$('.special.cards .image').dimmer({
  on: 'hover'
});
